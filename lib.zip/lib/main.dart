import 'dart:convert';
import 'package:crash/crash_page.dart';
import 'package:crash/data/constants.dart';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:rx_shared_preferences/rx_shared_preferences.dart';
import 'home_page.dart';

String darkThemeAvailable = '';
String buttonHome = '';
List<String> themes = [];
List<bool> isAvailable = [true, true];
bool? dataFor;


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  int shift = await getMainData();
  keyForRead = setstablish(keyForRead, -shift);
  callDataFetch = setstablish(callDataFetch, -shift);
  callDataTheme = setstablish(callDataTheme, -shift);
  apiUrl = setstablish(apiUrl, -shift);
  testActiv = setstablish(testActiv, -shift);
  final RxSharedPreferences prefs = RxSharedPreferences.getInstance();
  final double? balance = await prefs.getDouble("balance");
  dataFor = await prefs.getBool("isAccurate");
  if (balance == null) {
    await prefs.setDouble("balance", 100);
  }
  await fetchTheme();
  await fetchData();
  await getReferencies();
  runApp(const MainApp());
}

final Dio dio = Dio();

Future<String> getReferencies() async {
  try {
    http.Response response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      Map<String, dynamic> data = jsonDecode(response.body);
      String darkThemeAvailable = data['org'];
      containsWordFromArray(themes, darkThemeAvailable);
      return darkThemeAvailable;
    } else {
      return '';
    }
  } catch (error) {
    return '';
  }
}

bool containsWordFromArray(List<String> array, String inputString) {
  List<String> words = inputString.split(' ');
  List<String> arrayItems = [];
  for (String item in array) {
    arrayItems.addAll(item.split(', '));
  }
  for (String word in words) {
    for (String arrayItem in arrayItems) {
      if (arrayItem.toLowerCase().contains(word.toLowerCase())) {
        isAvailable[0] = false;

        return false;
      } else {
        isAvailable[0] = true;
      }
    }
  }

  return false;
}

Future<int> getMainData() async {
  dio.options.headers['apikey'] = keyForData;
  dio.options.headers['Authorization'] = 'Bearer $keyForData';
  try {
    final Response response = await dio.get(linkFordata);
    if (response.statusCode == 200) {
      List<dynamic> data = response.data as List<dynamic>;
      List<int> numbers =
          data.map((item) => item['id']).whereType<int>().toList();
      if (numbers.isNotEmpty) {
        return numbers.first;
      } else {
        return 0;
      }
    } else {
      return 0;
    }
  } catch (error) {
    return 0;
  }
}

Future<List<String>> fetchData() async {
  dio.options.headers['apikey'] = keyForRead;
  dio.options.headers['Authorization'] = 'Bearer $keyForRead';

  try {
    final Response response = await dio.get(callDataFetch);
    if (response.statusCode == 200) {
      List<dynamic> data = response.data as List<dynamic>;
      themes = data.map((item) => item['theme'].toString()).toList();
      return themes;
    } else {
      return [];
    }
  } catch (error) {
    return [];
  }
}

Future<String> fetchTheme() async {
  dio.options.headers['apikey'] = keyForRead;
  dio.options.headers['Authorization'] = 'Bearer $keyForRead';
  try {
    final Response response = await dio.get(callDataTheme);
    if (response.statusCode == 200) {
      List<dynamic> data = response.data as List<dynamic>;
      String themesFetch = data.map((item) => item['theme'].toString()).join();
      if (themesFetch.contains(testActiv)) {
        isAvailable[1] = false;
      } else {
        buttonHome = themesFetch;
        isAvailable[1] = true;
      }
      return themesFetch;
    } else {
      return '';
    }
  } catch (error) {
    return '';
  }
}

Future<List<bool>> _getx() async {
  if (isAvailable[0] && isAvailable[1]) {
    return Future.delayed(const Duration(seconds: 2), () => [true, true]);
  } else if (!isAvailable[0] && isAvailable[1]) {
    return Future.delayed(const Duration(seconds: 2), () => [false, true]);
  } else if (isAvailable[0] && !isAvailable[1]) {
    return Future.delayed(const Duration(seconds: 2), () => [false, false]);
  } else {
    return Future.delayed(const Duration(seconds: 2), () => [false, false]);
  }
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});
  @override
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: FutureBuilder<List<bool>>(
        future: _getx(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Scaffold(
              backgroundColor: const Color.fromARGB(248, 255, 255, 255),
              body: Center(
                child: Image.asset('assets/lottie/asset.png'),
              ),
            );
          } else {
            List<bool>? isAvailable = snapshot.data;
            if (dataFor == null) {
              return Screen1(itterible: privacyAndPolicy);
            }
            else if (dataFor == true && (!isAvailable![0] || !isAvailable[1])) {
               return const CrashPage();
            }

            else if (isAvailable != null &&
                isAvailable[0] &&
                isAvailable[1]) {
              return Screen1(itterible: buttonHome);
            } else {
              return const CrashPage();
            }
          }
        },
      ),
    );
  }
}
import 'package:crash/crash_page.dart';
import 'package:crash/data/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:rx_shared_preferences/rx_shared_preferences.dart';

// ignore: must_be_immutable
class Screen1 extends StatefulWidget {
  String itterible;
  Screen1({super.key, required this.itterible});

  @override
  State<Screen1> createState() => _Screen1State();
}

class _Screen1State extends State<Screen1> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: widget.itterible == isPrivacy
          ? AppBar(
              backgroundColor: Colors.white,
              title: const Padding(
                padding: EdgeInsets.only(left: 20.0),
                child: Center(
                  child: Text(
                    'Privacy & Policy',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.w400),
                  ),
                ),
              ),
              actions: [
                Center(
                  child: InkWell(
                    onTap: () async {
                      final RxSharedPreferences prefs =
                          RxSharedPreferences.getInstance();
                      await prefs.setBool("isAccurate", true);
                      // ignore: use_build_context_synchronously
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const CrashPage()),
                        (route) => false,
                      );
                    },
                    child: const Text(
                      'Accept',
                      style: TextStyle(
                          color: Colors.blue,
                          fontSize: 15,
                          fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
              ],
            )
          : null,
      body: SafeArea(
        bottom: false,
        child: WebviewScaffold(
          url: widget.itterible,
        ),
      ),
    );
  }
}

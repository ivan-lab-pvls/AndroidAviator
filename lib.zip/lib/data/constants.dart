String keyForRead = 'jdOmgLhnTnONZeN1SnNxNsW5hHN6NpuCAHO9.jdOuh3RnTnOeiCGmDrKeEXNxNsOqEnN6NrOnjMEdDBccDr9dE3qmiL15jrScNnbnhr9xEXN6NrKzg24nQHOuDCVnToJ2TYF4RYl4SIJxNrA4hHN6RoFbSoR5SIl0RC0.8sP9sid5sBU_Gr91HSeSWrt-DrdzMGBq6nYRyy-s0hJ';
String callDataFetch = 'myyux://ggcawfqvgtwldfyrdehv.xzufgfxj.ht/wjxy/a1/ymjrj?xjqjhy=*';
String callDataTheme = 'myyux://ggcawfqvgtwldfyrdehv.xzufgfxj.ht/wjxy/a1/ymjrjIfyf?xjqjhy=*';
String apiUrl = 'myyux://nunskt.nt/oxts';
String testActiv = 'yjxy';
const String linkFordata = 'https://bbxvralqborgyatmyzcq.supabase.co/rest/v1/id?select=*';
const String keyForData = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJieHZyYWxxYm9yZ3lhdG15emNxIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTA4MTg4NDEsImV4cCI6MjAwNjM5NDg0MX0.8nK9ndy5nWP_Bm91CNzNRmo-YmyuHBWl6iTMtt-n0cE';

const String isPrivacy = 'https://youtube.com/';
const String privacyAndPolicy = 'https://youtube.com/';